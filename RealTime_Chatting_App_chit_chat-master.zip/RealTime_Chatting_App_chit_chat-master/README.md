# RealTime_Chatting_App_chit_chat
<img src="https://user-images.githubusercontent.com/73985335/128609150-e4a57271-afe5-4e32-85b8-457cf52a3522.jpeg" width=50% height=50%>
<img src="https://user-images.githubusercontent.com/73985335/128609154-a0f5df3a-280d-4b82-b1e3-97247ed728be.jpeg" width=50% height=50%>
<img src="https://user-images.githubusercontent.com/73985335/128611245-d4e36454-379c-4012-bd93-77026081c249.jpeg" width=50% height=50%>

<img src="https://user-images.githubusercontent.com/73985335/128609161-ae1a3082-4d69-4488-9f0e-592defbe177f.jpeg" width=50% height=50%>
<img src="https://user-images.githubusercontent.com/73985335/128609166-a9a1816e-8951-44a2-b978-6462d88e4ad6.jpeg" width=50% height=50%>
<img src="https://user-images.githubusercontent.com/73985335/128609173-b436f43b-f6ba-4b83-b37d-dd56df3b2a24.jpeg" width=50% height=50%>
<img src="https://user-images.githubusercontent.com/73985335/128609175-9cc5145f-7b26-47d5-977a-ebd6ac30b59d.jpeg" width=50% height=50%>

